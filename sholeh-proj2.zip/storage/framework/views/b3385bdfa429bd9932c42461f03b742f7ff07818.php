<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <ul class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('datapeserta.index')); ?>">Data Peserta</a></li>
                <li class="active">View Data Peserta <b><?php echo e($datapeserta->nama); ?></b></li>
            </ul>
            <div class="panel panel-default">
                <div class="panel-heading">Data Peserta</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4 control-label">
                            <p>NIP</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php echo e($datapeserta->nis); ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Nama</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php echo e($datapeserta->nama); ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>No. Handpohone</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->nohp == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->nohp); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Email</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->email == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->email); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Jenis Kelamin</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->jeniskelamin == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->jeniskelamin); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Jenis kelas</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php echo e($datapeserta->jeniskelas->name); ?></p></b>
                        </div>
                        <?php if($datapeserta->jeniskelas_id == 1 || $datapeserta->jeniskelas_id == 3): ?>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Tempat, Tanggal Lahir</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->tempatlahir == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->tempatlahir); ?>, <?php echo e($datapeserta->tanggallahir); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Usia</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->usia == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->usia); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>No. HP Darurat</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->nohpdarurat == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->nohpdarurat); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Alamat Lengkap</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->alamatlengkap == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->alamatlengkap); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Didaftarkan Oleh</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->didaftarkanoleh == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->didaftarkanoleh); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Mengetahui Duta Bangsa</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->mengetahuidb == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->mengetahuidb); ?> <?php endif; ?></p></b>
                        </div>
                        <?php endif; ?>
                        <div class="col-md-4 control-label">
                            <p>Latar Belakang</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php echo e($datapeserta->latarbelakang); ?></p></b>
                        </div>
                        <?php if($datapeserta->latarbelakang == "bekerja"): ?>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Perusahaan</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->perusahaan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->perusahaan); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Jenis Industri</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->jenisindustri == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->jenisindustri); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Departemen</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->departemenpeserta == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->departemenpeserta); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Jabatan</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->jabatan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->jabatan); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Level Jabatan</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->leveljabatan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->leveljabatan); ?> <?php endif; ?></p></b>
                        </div>
                        <?php elseif($datapeserta->latarbelakang == "kuliah"): ?>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Universitas</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->universitas == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->universitas); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Jurusan</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->jurusan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->jurusan); ?> <?php endif; ?></p></b>
                        </div>
                        <?php elseif($datapeserta->latarbelakang == "sekolah"): ?>
                        <div class="col-md-4 control-label" style="text-align: center;background-color: #eaf0eb;">
                            <p>Sekolah</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->namasekolah == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->namasekolah); ?> <?php endif; ?></p></b>
                        </div>
                        <?php endif; ?>
                        <div class="col-md-4 control-label">
                            <p>Tanggal Pelaksanaan</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->tanggalpelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->tanggalpelaksanaan); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Judul Program</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->judulprogram == NULL): ?> - <?php else: ?> <?php echo e(strtoupper($datapeserta->judulprogram)); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Lokasi Pelaksanaan</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->lokasipelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->lokasipelaksanaan); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Kota Pelaksanaan</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->kotapelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->kotapelaksanaan); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Akun Instagram</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->akuninstagram == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->akuninstagram); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Materi</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->materi == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->materi); ?> <?php endif; ?></p></b>
                        </div>
                        <div class="col-md-4 control-label">
                            <p>Di Input Oleh</p>
                        </div>
                        <div class="col-md-6">
                            <b><p><?php if($datapeserta->posted_by == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->posted_by); ?>, <?php echo e($datapeserta->created_at); ?></p><?php endif; ?></b>
                        </div>
                        <div style="clear: both;">&nbsp;</div>
                        <div class="col-md-6 col-md-offset-4">
                            <a href="javascript:history.back(-1)" class="btn btn-primary">
                                <i class="fa fa-btn fa-back"></i> Back
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>