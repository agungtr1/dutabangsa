<div class="form-group<?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nama', 'Nama *', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('nama', null, ['class'=>'form-control','required'=>'required','placeholder'=>'Nama Lengkap']); ?>

        <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<!-- <div class="form-group<?php echo e($errors->has('nis') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nip', 'NIP', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('nis', null, ['class'=>'form-control','required'=>'required','placeholder'=>'Nomer Induk Siswa']); ?>

        <?php echo $errors->first('nis', '<p class="help-block">:message</p>'); ?>

    </div>
</div> -->

<div class="form-group<?php echo e($errors->has('nohp') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nohp', 'Nomer HP', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('nohp', null, ['class'=>'form-control','required'=>'required','placeholder'=>'Nomer Handphone']); ?>

        <?php echo $errors->first('nohp', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email', 'Alamat Email', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::email('email', null, ['class'=>'form-control','placeholder'=>'Alamat Email']); ?>

        <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('jeniskelamin') ? ' has-error' : ''); ?>">
    <?php echo Form::label('jeniskelamin', 'Jenis Kelamin', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('jeniskelamin', ['laki-laki'=>'Laki - Laki','perempuan'=>'Perempuan'], null, ['class'=>'form-control','placeholder' => 'Pilih Jenis Kelamin']); ?>

        <?php echo $errors->first('hakakses', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('jeniskelas_id') ? ' has-error' : ''); ?>">
    <?php echo Form::label('jeniskelas_id', 'Jenis Kelas *', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('jeniskelas_id', [''=>'']+App\Jeniskelas::pluck('name','id')->all(), null, ['class'=>'js-selectize','placeholder'=>'Pilih Kelas']); ?>

        <?php echo $errors->first('jeniskelas_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<!-- SHOW - - - HIDE !-->
<div style='display:none;background-color: #eaf0eb;' id='reguler'>

    <div class="form-group<?php echo e($errors->has('tempatlahir') ? 'has-error' : ''); ?>">
        <?php echo Form::label('tempatlahir', 'Tempat Kelahiran', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::text('tempatlahir', null, ['class'=>'form-control','placeholder'=>'Tempat Kelahiran']); ?>

            <?php echo $errors->first('tempatlahir', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('tanggallahir') ? 'has-error' : ''); ?>">
        <?php echo Form::label('tanggallahir', 'Tanggal Lahir', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
             <?php echo Form::date('tanggallahir', null, ['class'=>'form-control','placeholder'=>'dd-mm-yyyy']); ?>

            <?php echo $errors->first('tanggallahir', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('nohpdarurat') ? 'has-error' : ''); ?>">
        <?php echo Form::label('nohpdarurat', 'Nomer HP Darurat', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::number('nohpdarurat', null, ['class'=>'form-control','placeholder'=>'Nomer Handphone Darurat']); ?>

            <?php echo $errors->first('nohpdarurat', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('alamatlengkap') ? 'has-error' : ''); ?>">
        <?php echo Form::label('alamatlengkap', 'Alamat Lengkap', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::textarea('alamatlengkap', null, ['class'=>'form-control','placeholder'=>'Alamat Lengkap','rows'=>'3']); ?>

            <?php echo $errors->first('alamatlengkap', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('didaftarkanoleh') ? 'has-error' : ''); ?>">
        <?php echo Form::label('didaftarkanoleh', 'Didaftarkan Oleh', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::select('didaftarkanoleh', ['pribadi'=>'Pribadi','perusahaan'=>'Perusahaan','keluarga'=>'Keluarga','lainnya'=>'Lainnya'], null, ['id'=>'didaftarkanoleh','class'=>'form-control','placeholder' => 'Didaftarkan Oleh']); ?>

            <?php echo $errors->first('didaftarkanoleh', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <!-- SHOW - - - HIDE !-->
    <div style='display:none;background-color: #eaf0eb;' id='lainnya'>
        <div class="form-group<?php echo e($errors->has('didaftarkanoleh_lainnya') ? 'has-error' : ''); ?>">
            <?php echo Form::label('didaftarkanoleh_lainnya', 'Lainnya', ['class'=>'col-md-6 control-label']); ?>

            <div class="col-md-5">
                <?php echo Form::text('didaftarkanoleh_lainnya', null, ['class'=>'form-control','placeholder'=>'Ketik Lainnya']); ?>

                <?php echo $errors->first('didaftarkanoleh_lainnya', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <!-- END SHOW - - - HIDE !-->   

    <div class="form-group<?php echo e($errors->has('mengetahuidb') ? 'has-error' : ''); ?>">
        <?php echo Form::label('mengetahuidb', 'Bagaimana Mengetahui Duta Bangsa', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::select('mengetahuidb', ['website'=>'Website','instagram'=>'Instagram','twitter'=>'Twitter','facebook'=>'Facebook','linked in'=>'Linked In','teman'=>'Teman','saudara / keluarga'=>'Saudara / Keluarga','media cetak / elektronik'=>'Media Cetak / Elektronik','Lainnya'=>'Lainnya'], null, ['id'=>'mengetahuidb','class'=>'form-control','placeholder' => 'Mengetahui Duta Bangsa ?']); ?>

            <?php echo $errors->first('mengetahuidb', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <!-- SHOW - - - HIDE !-->
    <div style='display:none;background-color: #eaf0eb;' id='Lainnya'>
        <div class="form-group<?php echo e($errors->has('mengetahuidb_lainnya') ? 'has-error' : ''); ?>">
            <?php echo Form::label('mengetahuidb_lainnya', 'Lainnya', ['class'=>'col-md-6 control-label']); ?>

            <div class="col-md-5">
                <?php echo Form::text('mengetahuidb_lainnya', null, ['class'=>'form-control','placeholder'=>'Ketik Lainnya']); ?>

                <?php echo $errors->first('mengetahuidb_lainnya', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <!-- END SHOW - - - HIDE !-->

</div>
<!-- END SHOW - - - HIDE !-->

<!-- SHOW - - - HIDE !-->
<!-- <div style='display:none;background-color: #eaf0eb;' id='privateclass'>
    <div class="form-group<?php echo e($errors->has('didaftarkanoleh2') ? 'has-error' : ''); ?>">
        <?php echo Form::label('didaftarkanoleh2', 'Didaftarkan Oleh', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::select('didaftarkanoleh2', ['pribadi'=>'Pribadi','perusahaan'=>'Perusahaan','keluarga'=>'Keluarga','lain-lainnya'=>'Lainnya'], null, ['id'=>'didaftarkanoleh2','class'=>'form-control','placeholder' => 'Didaftarkan Oleh']); ?>

            <?php echo $errors->first('didaftarkanoleh', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    
    <div style='display:none;background-color: #eaf0eb;' id='lain-lainnya'>
        <div class="form-group<?php echo e($errors->has('didaftarkanoleh2_lainnya') ? 'has-error' : ''); ?>">
            <?php echo Form::label('didaftarkanoleh2_lainnya', 'Lainnya', ['class'=>'col-md-6 control-label']); ?>

            <div class="col-md-5">
                <?php echo Form::text('didaftarkanoleh2_lainnya', null, ['class'=>'form-control','placeholder'=>'Ketik Lainnya']); ?>

                <?php echo $errors->first('didaftarkanoleh2_lainnya', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    

    <div class="form-group<?php echo e($errors->has('mengetahuidb2_lainnya') ? 'has-error' : ''); ?>">
        <?php echo Form::label('mengetahuidb2_lainnya', 'Bagaimana Mengetahui Duta Bangsa', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::select('mengetahuidb2_lainnya', ['website'=>'Website','social media'=>'Social Media','teman'=>'Teman','saudara / keluarga'=>'Saudara / Keluarga','media cetak / elektronik'=>'Media Cetak / Elektronik','Lain-Lainnya'=>'Lainnya'], null, ['id'=>'mengetahuidb2','class'=>'form-control','placeholder' => 'Mengetahui Duta Bangsa ?']); ?>

            <?php echo $errors->first('mengetahuidb2_lainnya', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    
    <div style='display:none;background-color: #eaf0eb;' id='Lain-Lainnya'>
        <div class="form-group<?php echo e($errors->has('mengetahuidb2') ? 'has-error' : ''); ?>">
            <?php echo Form::label('mengetahuidb2', 'Lainnya', ['class'=>'col-md-6 control-label']); ?>

            <div class="col-md-5">
                <?php echo Form::text('mengetahuidb2', null, ['class'=>'form-control','placeholder'=>'Ketik Lainnya']); ?>

                <?php echo $errors->first('mengetahuidb2', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    
</div> -->
<!-- END SHOW - - - HIDE !-->

<div class="form-group<?php echo e($errors->has('latarbelakang') ? ' has-error' : ''); ?>">
    <?php echo Form::label('latarbelakang', 'Latar Belakang', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('latarbelakang', ['bekerja'=>'Bekerja','kuliah'=>'Kuliah','sekolah'=>'Sekolah'], null, ['id'=>'latarbelakang','class'=>'form-control','placeholder' => 'Latar Belakang Peserta']); ?>

        <?php echo $errors->first('latarbelakang', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<!-- SHOW - - - HIDE !-->
<div style='display:none;background-color: #eaf0eb;' id='bekerja'>
    
    <div class="form-group<?php echo e($errors->has('perusahaan') ? 'has-error' : ''); ?>">
        <?php echo Form::label('perusahaan', 'Perusahaan', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::text('perusahaan', null, ['class'=>'form-control','placeholder'=>'Perusahaan']); ?>

            <?php echo $errors->first('perusahaan', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('jenisindustri') ? ' has-error' : ''); ?>">
        <?php echo Form::label('jenisindustri', 'Jenis Industri', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::select('jenisindustri', [''=>'']+App\Jenisindustri::pluck('name','name')->all(), null, ['id'=>'jenisindustri','class'=>'form-control js-selectize','placeholder' => 'Jenis Industri']); ?>

            <?php echo $errors->first('jenisindustri', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('departemenpeserta') ? 'has-error' : ''); ?>">
        <?php echo Form::label('departemenpeserta', 'Departemen Peserta', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::text('departemenpeserta', null, ['class'=>'form-control','placeholder'=>'Departemen Peserta']); ?>

            <?php echo $errors->first('departemenpeserta', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('jabatan') ? 'has-error' : ''); ?>">
        <?php echo Form::label('jabatan', 'Jabatan', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::text('jabatan', null, ['class'=>'form-control','placeholder'=>'Jabatan']); ?>

            <?php echo $errors->first('jabatan', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('leveljabatan') ? ' has-error' : ''); ?>">
        <?php echo Form::label('leveljabatan', 'Level Jabatan', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::select('leveljabatan', ['top management'=>'Top management','middle management'=>'Middle Management','fresh graduate'=>'Fresh Graduate','lain-lainnya'=>'Lainnya'], null, ['id'=>'leveljabatan','class'=>'form-control','placeholder' => 'Level Jabatan']); ?>

            <?php echo $errors->first('leveljabatan', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <!-- SHOW - - - HIDE !-->
    <div style='display:none;background-color: #eaf0eb;' id='lain-lainnya'>
        <div class="form-group<?php echo e($errors->has('leveljabatan_lainnya') ? 'has-error' : ''); ?>">
            <?php echo Form::label('leveljabatan_lainnya', 'Lainnya', ['class'=>'col-md-6 control-label']); ?>

            <div class="col-md-5">
                <?php echo Form::text('leveljabatan_lainnya', null, ['class'=>'form-control','placeholder'=>'Ketik Lainnya']); ?>

                <?php echo $errors->first('leveljabatan_lainnya', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <!-- END SHOW - - - HIDE !-->

</div>

<div style='display:none;background-color: #eaf0eb;' id='kuliah'>
    
    <div class="form-group<?php echo e($errors->has('universitas') ? 'has-error' : ''); ?>">
        <?php echo Form::label('universitas', 'Universitas', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::text('universitas', null, ['class'=>'form-control','placeholder'=>'Universitas']); ?>

            <?php echo $errors->first('universitas', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('jurusan') ? 'has-error' : ''); ?>">
        <?php echo Form::label('jurusan', 'Jurusan', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::text('jurusan', null, ['class'=>'form-control','placeholder'=>'Jurusan']); ?>

            <?php echo $errors->first('jurusan', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

</div>

<div style='display:none;background-color: #eaf0eb;' id='sekolah'>
    
    <div class="form-group<?php echo e($errors->has('namasekolah') ? 'has-error' : ''); ?>">
        <?php echo Form::label('namasekolah', 'Nama Sekolah', ['class'=>'col-md-5 control-label']); ?>

        <div class="col-md-5">
            <?php echo Form::text('namasekolah', null, ['class'=>'form-control','placeholder'=>'Nama Sekolah']); ?>

            <?php echo $errors->first('namasekolah', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

</div>
<!-- END SHOW - - - HIDE !-->                    

<div class="form-group<?php echo e($errors->has('tanggalpelaksanaan') ? 'has-error' : ''); ?>">
    <?php echo Form::label('tanggalpelaksanaan', 'Tanggal Pelaksanaan *', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::date('tanggalpelaksanaan', null, ['class'=>'form-control','required'=>'required','placeholder'=>'dd-mm-yyyy']); ?>

        <?php echo $errors->first('tanggalpelaksanaan', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('judulprogram') ? 'has-error' : ''); ?>">
    <?php echo Form::label('judulprogram', 'Judul Program', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('judulprogram', null, ['class'=>'form-control','placeholder'=>'Judul Program']); ?>

        <?php echo $errors->first('judulprogram', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('materi') ? ' has-error' : ''); ?>">
    <?php echo Form::label('materi', 'Materi *', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <div class="materi">
        <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materis): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <span style="white-space: nowrap;" class="materihover"><label><?php echo Form::checkbox('materi[]', $materis->name); ?> <?php echo e($materis->name); ?></label></span><br/>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
        <?php echo $errors->first('materi', '<p class="help-block">:message</p>'); ?>

    </div> 
</div>

<div class="form-group<?php echo e($errors->has('lokasipelaksanaan') ? 'has-error' : ''); ?>">
    <?php echo Form::label('lokasipelaksanaan', 'Lokasi Pelaksanaan', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('lokasipelaksanaan', null, ['class'=>'form-control','placeholder'=>'Lokasi Pelaksanaan']); ?>

        <small>Contoh : LPPI, Kemang</small>
        <?php echo $errors->first('lokasipelaksanaan', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('kotapelaksanaan') ? 'has-error' : ''); ?>">
    <?php echo Form::label('kotapelaksanaan', 'Kota Pelaksanaan', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('kotapelaksanaan', null, ['class'=>'form-control','placeholder'=>'Kota Pelaksanaan']); ?>

        <small>Contoh : Jakarta</small>
        <?php echo $errors->first('kotapelaksanaan', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('akuninstagram') ? 'has-error' : ''); ?>">
    <?php echo Form::label('akuninstagram', 'Akun Instagram', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('akuninstagram', null, ['class'=>'form-control','placeholder'=>'Instagram']); ?>

        <small>bila ada</small>
        <?php echo $errors->first('akuninstagram', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<!-- <div class="form-group">
    <?php echo Form::label('posted_by', 'posted_by', ['class'=>'col-md-4 control-label']); ?>

    <div class="col-md-6"> -->
        <?php echo Form::hidden('posted_by', Auth::user()->name, ['class'=>'form-control','placeholder'=>'Instagram','readonly'=>'readonly']); ?>

    <!-- </div>
    </div> -->

<div class="form-group">
    <div class="col-md-6 col-md-offset-4">
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-btn fa-user"></i> Submit
        </button>
    </div>
</div>