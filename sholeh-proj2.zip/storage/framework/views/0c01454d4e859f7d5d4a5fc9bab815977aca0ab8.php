<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <ul class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('listdatapeserta.index')); ?>">Data Peserta</a></li>
                <li class="active">Tambah Data Peserta Baru</b></li>
            </ul>
            <div class="panel panel-default">
                <div class="panel-heading">Tambah Data Peserta Baru</div>
                <div class="panel-body">
                    <?php echo Form::open(['url'=>route('listdatapeserta.store'), 'method'=>'post', 'class'=>'form-horizontal']); ?>

                        <?php echo $__env->make('datapeserta._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::close(); ?>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/panggil.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>