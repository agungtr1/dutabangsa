<!DOCTYPE html>
<html>
<head>
	<title>Report Data Peserta</title>
	<style>
        /* --------------------------------------------------------------
        Hartija Css Print Framework
        * Version: 1.0
        -------------------------------------------------------------- */
        body {
        width:100% !important;
        margin:0 !important;
        padding:0 !important;
        line-height: 1.45;
        font-family: Garamond,"Times New Roman", serif;
        color: #000;
        background: none;
        font-size: 14pt; }
        /* Headings */
        h1,h2,h3,h4,h5,h6 { page-break-after:avoid; }
        h1{font-size:19pt;}
        h2{font-size:17pt;}
        h3{font-size:15pt;}
        h4,h5,h6{font-size:14pt;}
        p, h2, h3 { orphans: 3; widows: 3; }
        code { font: 12pt Courier, monospace; }
        blockquote { margin: 1.2em; padding: 1em; font-size: 12pt; }
        hr { background-color: #ccc; }
        /* Images */
        img { float: left; margin: 1em 1.5em 1.5em 0; max-width: 100% !important; }
        a img { border: none; }
        /* Links */
        a:link, a:visited { background: transparent; font-weight: 700; text-decoration: underline;color:#333; }
        a:link[href^="http://"]:after, a[href^="http://"]:visited:after { content: " (" attr(href) ")"; font-size: 90%; }
        abbr[title]:after { content: " (" attr(title) ")"; }
        /* Don't show linked images */
        a[href^="http://"] {color:#000; }
        a[href$=".jpg"]:after, a[href$=".jpeg"]:after, a[href$=".gif"]:after, a[href$=".png"]:after {content: " (" attr(href) ") "; display:none; }
        /* Don't show links that are fragment identifiers, or use the `javascript:` pseudo protocol . . taken from html5boilerplate */
        a[href^="#"]:after, a[href^="javascript:"]:after {content: "";}
        /* Table */
        table { margin: 1px; text-align:left; }
        th { border-bottom: 1px solid #333; font-weight: bold; }
        td { border-bottom: 1px solid #333; }
        th,td { padding: 4px 10px 4px 0; }
        tfoot { font-style: italic; }
        caption { background: #fff; margin-bottom:2em; text-align:left; }
        thead {display: table-header-group;}
        img,tr {page-break-inside: avoid;}
        /* Hide various parts from the site
        #header, #footer, #navigation, #rightSideBar, #leftSideBar
        {display:none;}
        */
    </style>
</head>
<body>
	<h1>Data Peserta Duta Bangsa</h1>
    <hr>
    <table>
        <thead style="text-align: center;">
            <tr>
                <td>Keterangan</td>
                <td>Data Peserta</td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>NIS</td>
                <td><b><?php echo e($datapeserta->nis); ?></b></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td><b><?php echo e($datapeserta->nama); ?></b></td>
            </tr>
            <tr>
                <td>No. Handpohone</td>
                <td><b><?php if($datapeserta->nohp == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->nohp); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><b><?php if($datapeserta->email == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->email); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td><b><?php if($datapeserta->jeniskelamin == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->jeniskelamin); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Jenis kelas</td>
                <td><b><?php echo e($datapeserta->jeniskelas->name); ?></b></td>
            </tr>
            <?php if($datapeserta->jeniskelas->id == 1 || $datapeserta->jeniskelas->id == 3): ?>
            <tr>
                <td>Tempat, Tanggal Lahir</td>
                <td><b><?php if($datapeserta->tempatlahir == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->tempatlahir); ?>, <?php echo e($datapeserta->tanggallahir); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Usia</td>
                <td><b><?php if($datapeserta->usia == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->usia); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>No. HP Darurat</td>
                <td><b><?php if($datapeserta->nohpdarurat == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->nohpdarurat); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Alamat Lengkap</td>
                <td><b><?php if($datapeserta->alamatlengkap == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->alamatlengkap); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Didaftarkan Oleh</td>
                <td><b><?php if($datapeserta->didaftarkanoleh == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->didaftarkanoleh); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Mengetahui Duta Bangsa</td>
                <td><b><?php if($datapeserta->mengetahuidb == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->mengetahuidb); ?> <?php endif; ?></b></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td>Latar Belakang</td>
                <td><b><?php if($datapeserta->latarbelakang == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->latarbelakang); ?> <?php endif; ?></b></td>
            </tr>
            <?php if($datapeserta->latarbelakang == "bekerja"): ?>
            <tr>
                <td>Perusahaan</td>
                <td><b><?php if($datapeserta->perusahaan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->perusahaan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Jenis Industri</td>
                <td><b><?php if($datapeserta->jenisindustri == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->jenisindustri); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Departemen</td>
                <td><b><?php if($datapeserta->departemenpeserta == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->departemenpeserta); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Jabatan</td>
                <td><b><?php if($datapeserta->jabatan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->jabatan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Level Jabatan</td>
                <td><b><?php if($datapeserta->leveljabatan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->leveljabatan); ?> <?php endif; ?></b></td>
            </tr>
            <?php elseif($datapeserta->latarbelakang == "kuliah"): ?>
            <tr>
                <td>Universitas</td>
                <td><b><?php if($datapeserta->universitas == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->universitas); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Jurusan</td>
                <td><b><?php if($datapeserta->jurusan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->jurusan); ?> <?php endif; ?></b></td>
            </tr>
            <?php elseif($datapeserta->latarbelakang == "sekolah"): ?>
            <tr>
                <td>Sekolah</td>
                <td><b><?php if($datapeserta->namasekolah == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->namasekolah); ?> <?php endif; ?></b></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td>Tanggal Pelaksanaan</td>
                <td><b><?php if($datapeserta->tanggalpelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->tanggalpelaksanaan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Judul Program</td>
                <td><b><?php if($datapeserta->judulprogram == NULL): ?> - <?php else: ?> <?php echo e(strtoupper($datapeserta->judulprogram)); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Lokasi Pelaksanaan</td>
                <td><b><?php if($datapeserta->lokasipelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->lokasipelaksanaan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Kota Pelaksanaan</td>
                <td><b><?php if($datapeserta->kotapelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->kotapelaksanaan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Akun Instagram</td>
                <td><b><?php if($datapeserta->akuninstagram == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->akuninstagram); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Materi</td>
                <td><b><?php if($datapeserta->materi == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->materi); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Di Input Oleh</td>
                <td><b><?php if($datapeserta->posted_by == NULL): ?> - <?php else: ?> <?php echo e($datapeserta->posted_by); ?>, <?php echo e($datapeserta->created_at); ?> <?php endif; ?></b></td>
            </tr>
            <tr> 
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
            </tr>
            <tr> 
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
            </tr>
            
        </tbody>
    </table>
</body>
</html>
<script type="text/javascript">
    window.print();
</script>