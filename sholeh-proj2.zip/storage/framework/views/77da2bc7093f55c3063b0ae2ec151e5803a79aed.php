<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <ul class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('datapeserta.index')); ?>">Data Peserta</a></li>
                <li class="active">Export Data Peserta</li>
            </ul>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="panel-title">Export Data Peserta</h2>
                </div>
                <div class="panel-body">
                    <div class="row">
                    <?php echo Form::open(['url'=>route('export.datapesertaall.post'),'method'=>'post','class'=>'form-horizontal','role'=>'form','id'=>'filter-form']); ?>    
                        <div class="col-md-8">
                            <div class="form-group<?php echo e($errors->has('filter') ? ' has-error' : ''); ?>">
                                <?php echo Form::label('filter', 'Export Semua Data', ['class'=>'col-md-3 control-label']); ?>

                                <div class="col-md-7">
                                <?php echo Form::select('filter', ['all'=>'Semua Waktu','bulanan'=>'Per Bulan Ini','tahunan'=>'Per Tahun Ini','tanggal'=>'Berdasarkan Tanggal'], 'all', ['id'=>'filter','class'=>'form-control','placeholder' => 'Pilih Waktu']); ?>

                                <?php echo $errors->first('filter', '<p class="help-block">:message</p>'); ?>

                                <!-- SHOW - - - HIDE ! -->
                                <div style='display:none;margin-top: 5px;margin-left: 1px;' id='tanggal' class="row">
                                    <div class="form-group">
                                        <div class="col-md-5">
                                        <?php echo Form::date('dari', date('Y-m-d'), ['class'=>'form-control','placeholder'=>'yyyy-mm-dd']); ?>

                                        </div>
                                        <div class="col-md-1">
                                        s/d
                                        </div>
                                        <div class="col-md-5">
                                        <?php echo Form::date('sampai', date('Y-m-d'), ['class'=>'form-control','placeholder'=>'yyyy-mm-dd']); ?>

                                        </div>
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-1">
                                    <button class="btn btn-info" type="submit"><i class="fa fa-btn fa-print"></i> Export Semua Data</button>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="col-md-2">
                            <a class="btn btn-info" href="<?php echo e(route('export.datapesertaall.post')); ?>"><i class="fa fa-btn fa-print"></i> Export Semua Data</a>
                        </div> -->
                    <?php echo Form::close(); ?>

                    </div>
                    <div class="row">
                    <hr/>
                        <div class="col-md-2">
                            &nbsp;
                        </div>
                        <div class="col-md-4">
                            <b>Atau Pilih Nama Peserta</b>
                        </div>
                    </div>
                    <hr/>
                    <div style="clear: both;">&nbsp;</div>
                    <?php echo Form::open(['url' => route('export.datapeserta.post'),'method' => 'post', 'class'=>'form-horizontal']); ?>

                    <div class="form-group <?php echo $errors->has('id') ? 'has-error' : ''; ?>">
                        <?php echo Form::label('id', 'Peserta', ['class'=>'col-md-2 control-label']); ?>

                        <div class="col-md-4">
                        <?php echo Form::select('id[]', [''=>'']+App\Peserta::pluck('nama','id')->all(),null, ['class'=>'js-selectize','multiple','placeholder' => 'Pilih Nama Peserta']); ?>

                        <?php echo $errors->first('id', '<p class="help-block">:message</p>'); ?>

                        </div>
                    </div>
                    <div class="form-group <?php echo $errors->has('type') ? 'has-error' : ''; ?>">
                        <?php echo Form::label('type', 'Pilih Output', ['class'=>'col-md-2 control-label']); ?>

                        <div class="col-md-4 checkbox">
                            <?php echo e(Form::radio('type', 'xls', true)); ?> Excel
                            <?php echo e(Form::radio('type', 'pdf')); ?> PDF
                            <?php echo $errors->first('type', '<p class="help-block">:message</p>'); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-4 col-md-offset-2">
                        <?php echo Form::submit('Download', ['class'=>'btn btn-primary','target'=>'_blank']); ?>

                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    {     
         $(document).ready(function(){
            $('#filter').on('change', function() {
                if ( this.value == 'tanggal')
                {
                    $("#tanggal").show();
                }
                else
                {
                    $("#tanggal").hide();
                }
                
            });


    });  }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>