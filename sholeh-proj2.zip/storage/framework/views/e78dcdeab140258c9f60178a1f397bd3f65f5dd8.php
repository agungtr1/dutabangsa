<?php echo Form::model($model, ['url'=>$form_url, 'method'=>'delete','class'=>'form-inline js-confirm','data-confirm'=>$confirm_message]); ?>

	<a href="<?php echo e($show_url); ?>" class="btn btn-xs btn-success"><i class="fa fa-btn fa-eye"></i></a>
	<a href="<?php echo e($print_url); ?>" class="btn btn-xs btn-default" target="_blank"><i class="fa fa-btn fa-print"></i></a>
	<a href="<?php echo e($edit_url); ?>" class="btn btn-xs btn-info"><i class="fa fa-btn fa-pencil"></i></a>
	<?php echo Form::button('<i class="fa fa-btn fa-trash"></i>', ['type' => 'submit', 'class'=>'btn btn-xs btn-danger']); ?>

<?php echo Form::close(); ?>