<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <ul class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li class="active">Data Peserta</li>
            </ul>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="panel-title">Data Peserta</h2>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-2">
                            <a class="btn btn-primary" href="<?php echo e(route('datapeserta.create')); ?>">Tambah</a> 
                            <a class="btn btn-default" href="<?php echo e(route('export.datapeserta')); ?>"><i class="fa fa-btn fa-print"></i> Export</a>
                        </div>
                        <div class="col-md-10">
                        
                            <?php echo Form::open(['method'=>'post','class'=>'form-horizontal','role'=>'form','id'=>'filter-form']); ?>

                            <div class="form-group<?php echo e($errors->has('filter') ? ' has-error' : ''); ?>">
                                <?php echo Form::label('filter', 'FIlter:', ['class'=>'col-md-1 control-label']); ?>

                                <div class="col-md-3">
                                
                                <?php echo Form::text('filter', null, ['class'=>'form-control','placeholder'=>'search by nama']); ?>

                                            </div>
                                <button type="submit" class="btn btn-primary"><i class="fa fa-btn fa-search"></i> </button>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                    <?php echo $html->table(['id'=>'datapeserta','class'=>'table-striped']); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $html->scripts(); ?>

    <script type="text/javascript">
    {     
         $(document).ready(function(){
            $('#filter').on('change', function() {
                if ( this.value == 'tanggal')
                {
                    $("#tanggal").show();
                }
                else
                {
                    $("#tanggal").hide();
                }
                
            });


    });  }
    </script>
    <script>
      function submitForm(elem) {
          if (elem.value == 'all' || elem.value == 'tahunan' || elem.value == 'bulanan') {
              elem.form.submit();
          }else if (elem.value == 'tanggal') {
            console.log('dapet nih');
          }
      }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>