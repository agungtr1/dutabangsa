<!DOCTYPE html>
<html>
    <head>
    <title>Data Peserta Duta Bangsa</title>
    <style>
        /* --------------------------------------------------------------
        Hartija Css Print Framework
        * Version: 1.0
        -------------------------------------------------------------- */
        body {
        width:100% !important;
        margin:0 !important;
        padding:0 !important;
        line-height: 1.45;
        font-family: Garamond,"Times New Roman", serif;
        color: #000;
        background: none;
        font-size: 14pt; }
        /* Headings */
        h1,h2,h3,h4,h5,h6 { page-break-after:avoid; }
        h1{font-size:19pt;}
        h2{font-size:17pt;}
        h3{font-size:15pt;}
        h4,h5,h6{font-size:14pt;}
        p, h2, h3 { orphans: 3; widows: 3; }
        code { font: 12pt Courier, monospace; }
        blockquote { margin: 1.2em; padding: 1em; font-size: 12pt; }
        hr { background-color: #ccc; }
        /* Images */
        img { float: left; margin: 1em 1.5em 1.5em 0; max-width: 100% !important; }
        a img { border: none; }
        /* Links */
        a:link, a:visited { background: transparent; font-weight: 700; text-decoration: underline;color:#333; }
        a:link[href^="http://"]:after, a[href^="http://"]:visited:after { content: " (" attr(href) ")"; font-size: 90%; }
        abbr[title]:after { content: " (" attr(title) ")"; }
        /* Don't show linked images */
        a[href^="http://"] {color:#000; }
        a[href$=".jpg"]:after, a[href$=".jpeg"]:after, a[href$=".gif"]:after, a[href$=".png"]:after {content: " (" attr(href) ") "; display:none; }
        /* Don't show links that are fragment identifiers, or use the `javascript:` pseudo protocol . . taken from html5boilerplate */
        a[href^="#"]:after, a[href^="javascript:"]:after {content: "";}
        /* Table */
        table { margin: 1px; text-align:left; }
        th { border-bottom: 1px solid #333; font-weight: bold; }
        td { border-bottom: 1px solid #333; }
        th,td { padding: 4px 10px 4px 0; }
        tfoot { font-style: italic; }
        caption { background: #fff; margin-bottom:2em; text-align:left; }
        thead {display: table-header-group;}
        img,tr {page-break-inside: avoid;}
        /* Hide various parts from the site
        #header, #footer, #navigation, #rightSideBar, #leftSideBar
        {display:none;}
        */
    </style>
</head>

<body>
    <h1>Data Peserta Duta Bangsa</h1>
    <hr>
    <table>
        <thead style="text-align: center;">
            <tr>
                <td>Keterangan</td>
                <td>Data Peserta</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datapeserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td>NIS</td>
                <td><b><?php echo e($dp->nis); ?></b></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td><b><?php echo e($dp->nama); ?></b></td>
            </tr>
            <tr>
                <td>No. Handpohone</td>
                <td><b><?php if($dp->nohp == NULL): ?> - <?php else: ?> <?php echo e($dp->nohp); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><b><?php if($dp->email == NULL): ?> - <?php else: ?> <?php echo e($dp->email); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td><b><?php if($dp->jeniskelamin == NULL): ?> - <?php else: ?> <?php echo e($dp->jeniskelamin); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Jenis kelas</td>
                <td><b><?php echo e($dp->jeniskelas->name); ?></b></td>
            </tr>
            <?php if($dp->jeniskelas->id == 1): ?>
            <tr>
                <td>Tempat, Tanggal Lahir</td>
                <td><b><?php if($dp->tempatlahir == NULL): ?> - <?php else: ?> <?php echo e($dp->tempatlahir); ?>, <?php echo e($dp->tanggallahir); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>No. HP Darurat</td>
                <td><b><?php if($dp->nohpdarurat == NULL): ?> - <?php else: ?> <?php echo e($dp->nohpdarurat); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Alamat Lengkap</td>
                <td><b><?php if($dp->alamatlengkap == NULL): ?> - <?php else: ?> <?php echo e($dp->alamatlengkap); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Didaftarkan Oleh</td>
                <td><b><?php if($dp->didaftarkanoleh == NULL): ?> - <?php else: ?> <?php echo e($dp->didaftarkanoleh); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Mengetahui Duta Bangsa</td>
                <td><b><?php if($dp->mengetahuidb == NULL): ?> - <?php else: ?> <?php echo e($dp->mengetahuidb); ?> <?php endif; ?></b></td>
            </tr>
            <?php elseif($jeniskelas->id == 3): ?>
            <tr>
                <td>Didaftarkan Oleh</td>
                <td><b><?php if($dp->didaftarkanoleh == NULL): ?> - <?php else: ?> <?php echo e($dp->didaftarkanoleh); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Mengetahui Duta Bangsa</td>
                <td><b><?php if($dp->mengetahuidb == NULL): ?> - <?php else: ?> <?php echo e($dp->mengetahuidb); ?> <?php endif; ?></b></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td>Latar Belakang</td>
                <td><b><?php if($dp->latarbelakang == NULL): ?> - <?php else: ?> <?php echo e($dp->latarbelakang); ?> <?php endif; ?></b></td>
            </tr>
            <?php if($dp->latarbelakang == "bekerja"): ?>
            <tr>
                <td>Perusahaan</td>
                <td><b><?php if($dp->perusahaan == NULL): ?> - <?php else: ?> <?php echo e($dp->perusahaan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Departemen</td>
                <td><b><?php if($dp->departemenpeserta == NULL): ?> - <?php else: ?> <?php echo e($dp->departemenpeserta); ?> <?php endif; ?></b></td>
            </tr>
            <?php elseif($dp->latarbelakang == "kuliah"): ?>
            <tr>
                <td>Universitas</td>
                <td><b><?php if($dp->universitas == NULL): ?> - <?php else: ?> <?php echo e($dp->universitas); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Jurusan</td>
                <td><b><?php if($dp->jurusan == NULL): ?> - <?php else: ?> <?php echo e($dp->jurusan); ?> <?php endif; ?></b></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td>Tanggal Pelaksanaan</td>
                <td><b><?php if($dp->tanggalpelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($dp->tanggalpelaksanaan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Judul Program</td>
                <td><b><?php if($dp->judulprogram == NULL): ?> - <?php else: ?> <?php echo e($dp->judulprogram); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Lokasi Pelaksanaan</td>
                <td><b><?php if($dp->lokasipelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($dp->lokasipelaksanaan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Kota Pelaksanaan</td>
                <td><b><?php if($dp->kotapelaksanaan == NULL): ?> - <?php else: ?> <?php echo e($dp->kotapelaksanaan); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Akun Instagram</td>
                <td><b><?php if($dp->akuninstagram == NULL): ?> - <?php else: ?> <?php echo e($dp->akuninstagram); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Materi</td>
                <td><b><?php if($dp->materi == NULL): ?> - <?php else: ?> <?php echo e($dp->materi); ?> <?php endif; ?></b></td>
            </tr>
            <tr>
                <td>Di Input Oleh</td>
                <td><b><?php if($dp->posted_by == NULL): ?> - <?php else: ?> <?php echo e($dp->posted_by); ?>, <?php echo e($dp->created_at); ?> <?php endif; ?></b></td>
            </tr>
            <tr> 
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
            </tr>
            <tr> 
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
    </table>
</body>
</html>